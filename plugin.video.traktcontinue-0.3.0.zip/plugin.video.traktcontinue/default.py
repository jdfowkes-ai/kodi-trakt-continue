import sys
import json
import time
import urllib.parse
import urllib.request
import urllib.error
import os
import hashlib
import datetime

import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin

ADDON = xbmcaddon.Addon()
HANDLE = int(sys.argv[1])
BASE = sys.argv[0]
API = 'https://api.trakt.tv'


def setting(name):
    return ADDON.getSetting(name).strip()


def url(action):
    return BASE + '?' + urllib.parse.urlencode({'action': action})


def api(path, method='GET', payload=None, authenticated=True):
    client = setting('client_id')
    if not client:
        raise RuntimeError('Enter your Trakt Client ID in add-on settings first.')
    headers = {'Content-Type': 'application/json', 'trakt-api-version': '2', 'trakt-api-key': client, 'User-Agent': 'KodiTraktContinue/0.3.0'}
    if authenticated:
        token = setting('access_token')
        if not token:
            raise RuntimeError('Authorize Trakt from the add-on main menu first.')
        headers['Authorization'] = 'Bearer ' + token
    req = urllib.request.Request(API + path, data=json.dumps(payload).encode('utf-8') if payload is not None else None, headers=headers, method=method)
    try:
        with urllib.request.urlopen(req, timeout=20) as response:
            return json.loads(response.read().decode('utf-8'))
    except urllib.error.HTTPError as exc:
        # Preserve Trakt's error details during setup. Never display credentials or tokens.
        try:
            body = json.loads(exc.read().decode('utf-8'))
        except Exception:
            body = {}
        if exc.code == 429:
            raise RuntimeError('Trakt rate limit reached. Try again later.')
        if exc.code == 401 and authenticated:
            raise RuntimeError('Trakt rejected the saved login (HTTP 401). Please reauthorize.')
        detail = body.get('error_description') or body.get('error') or body.get('message') or ''
        if not isinstance(detail, str):
            detail = ''
        detail = detail[:180]
        raise RuntimeError('Trakt HTTP %s at %s%s' % (exc.code, path.split('?')[0], (': ' + detail) if detail else ''))


def add(label, action, info=None):
    item = xbmcgui.ListItem(label=label)
    if info:
        item.setInfo('video', info)
    xbmcplugin.addDirectoryItem(HANDLE, url(action), item, True)


def authorize():
    if not setting('client_id'):
        xbmcgui.Dialog().ok('Trakt setup', 'Open add-on Settings and enter your Trakt Client ID.')
        ADDON.openSettings()
        return
    code = api('/oauth/device/code', method='POST', payload={'client_id': setting('client_id')}, authenticated=False)
    dialog = xbmcgui.DialogProgress()
    dialog.create('Authorize Kodi Trakt Continue', 'Visit %s and enter code %s' % (code.get('verification_url', 'https://trakt.tv/activate'), code['user_code']))
    interval = max(5, int(code.get('interval', 5)))
    deadline = time.time() + int(code.get('expires_in', 600))
    try:
        while time.time() < deadline and not dialog.iscanceled():
            xbmc.sleep(interval * 1000)
            try:
                tokens = api('/oauth/device/token', method='POST', payload={'code': code['device_code'], 'client_id': setting('client_id')}, authenticated=False)
                ADDON.setSetting('access_token', tokens['access_token'])
                ADDON.setSetting('refresh_token', tokens.get('refresh_token', ''))
                xbmcgui.Dialog().notification('Trakt', 'Authorization successful', xbmcgui.NOTIFICATION_INFO)
                return
            except RuntimeError as exc:
                # 400/404 are expected while user has not yet approved device code.
                if ('HTTP 400 at /oauth/device/token' not in str(exc) and
                        'HTTP 404 at /oauth/device/token' not in str(exc)):
                    raise
    finally:
        dialog.close()


def recent_movies():
    # Trakt playback records are unfinished films with actual resume percentages.
    data = api('/sync/playback/movies?limit=100')
    out = []
    for entry in data:
        movie = entry.get('movie') or {}
        title = movie.get('title', 'Unknown movie')
        percent = float(entry.get('progress') or 0)
        if 0 < percent < 100:
            out.append({'kind': 'movie', 'title': title, 'date': entry.get('paused_at', ''), 'progress': percent, 'ids': movie.get('ids') or {}, 'year': movie.get('year') or ''})
    return out


def recent_shows():
    # Trakt's watched shows carry last_watched_at; next_episode is computed from progress endpoint.
    watched = api('/sync/watched/shows?extended=noseasons')
    out = []
    for entry in watched[:60]:
        show = entry.get('show') or {}
        ids = show.get('ids') or {}
        identifier = ids.get('trakt')
        if not identifier:
            continue
        progress = api('/shows/%s/progress/watched?hidden=false&specials=false' % identifier)
        nxt = progress.get('next_episode')
        if not nxt:
            continue
        season, number = nxt.get('season'), nxt.get('number')
        if season is None or number is None:
            continue
        title = show.get('title', 'Unknown series')
        out.append({'kind': 'episode', 'title': title, 'episode': 'S%02dE%02d' % (season, number), 'date': entry.get('last_watched_at') or '', 'episode_title': nxt.get('title') or '', 'ids': ids, 'year': show.get('year') or '', 'season': season, 'number': number})
    return out


def umbrella_url(entry):
    """Experimental Umbrella play route. Verify against installed Umbrella version."""
    ids = entry.get('ids') or {}
    params = {
        'action': 'play',
        'title': entry['title'],
        'year': str(entry.get('year') or ''),
        'imdb': str(ids.get('imdb') or ''),
        'tmdb': str(ids.get('tmdb') or ''),
        'select': '0',
    }
    if entry['kind'] == 'episode':
        params.update({
            'tvshowtitle': entry['title'],
            'season': str(entry['season']),
            'episode': str(entry['number']),
            'premiered': '',
        })
    return 'plugin://plugin.video.umbrella/?' + urllib.parse.urlencode(params)



# TMDb provides licensed artwork, plot and UK classifications. OMDb can supply
# IMDb ratings and Rotten Tomatoes critic scores with a user-supplied API key.
TMDB = 'https://api.themoviedb.org/3'
OMDB = 'https://www.omdbapi.com/'
CACHE_DIR = xbmc.translatePath('special://profile/addon_data/plugin.video.traktcontinue/metadata_cache')


def cached_json(url, days=7):
    os.makedirs(CACHE_DIR, exist_ok=True)
    name = hashlib.sha256(url.encode('utf-8')).hexdigest() + '.json'
    path = os.path.join(CACHE_DIR, name)
    if os.path.exists(path) and time.time() - os.path.getmtime(path) < days * 86400:
        try:
            with open(path, encoding='utf-8') as f:
                return json.load(f)
        except Exception:
            pass
    req = urllib.request.Request(url, headers={'User-Agent': 'KodiTraktContinue/0.3.0'})
    try:
        with urllib.request.urlopen(req, timeout=8) as response:
            result = json.loads(response.read().decode('utf-8'))
        with open(path, 'w', encoding='utf-8') as f:
            json.dump(result, f)
        return result
    except Exception as exc:
        xbmc.log('[Kodi Trakt Continue] Metadata fetch failed: %s' % type(exc).__name__, xbmc.LOGWARNING)
        return {}


def tmdb_get(path, **kwargs):
    key = setting('tmdb_key')
    if not key:
        return {}
    params = {'api_key': key, 'language': 'en-GB'}
    params.update(kwargs)
    return cached_json(TMDB + path + '?' + urllib.parse.urlencode(params))


def omdb_get(imdb):
    key = setting('omdb_key')
    if not key or not imdb:
        return {}
    return cached_json(OMDB + '?' + urllib.parse.urlencode({'apikey': key, 'i': imdb, 'tomatoes': 'true'}))


def uk_movie_certificate(data):
    for country in (data.get('release_dates') or {}).get('results', []):
        if country.get('iso_3166_1') == 'GB':
            for release in sorted(country.get('release_dates', []), key=lambda r: bool(r.get('certification')), reverse=True):
                cert = release.get('certification', '').strip()
                if cert:
                    return cert
    return ''


def uk_tv_certificate(data):
    for entry in (data.get('content_ratings') or {}).get('results', []):
        if entry.get('iso_3166_1') == 'GB':
            return entry.get('rating', '')
    return ''


def artwork_url(path, size):
    return 'https://image.tmdb.org/t/p/' + size + path if path else ''


def enrich(entry):
    info = {'title': entry['title'], 'mediatype': 'movie' if entry['kind'] == 'movie' else 'episode'}
    art = {}
    properties = {}
    ids = entry.get('ids') or {}
    tmdb_id = ids.get('tmdb')
    is_movie = entry['kind'] == 'movie'
    if entry.get('year'):
        info['year'] = int(entry['year'])
    if not is_movie:
        info.update({'tvshowtitle': entry['title'], 'season': entry['season'], 'episode': entry['number']})
        if entry.get('episode_title'):
            info['title'] = entry['episode_title']
    data = {}
    if tmdb_id:
        path = ('/movie/' if is_movie else '/tv/') + str(tmdb_id)
        data = tmdb_get(path, append_to_response='release_dates' if is_movie else 'content_ratings')
    if data:
        info['plot'] = data.get('overview') or ''
        info['originaltitle'] = data.get('original_title') or data.get('original_name') or entry['title']
        if data.get('genres'):
            info['genre'] = [g['name'] for g in data['genres'] if g.get('name')]
        if data.get('runtime'):
            info['duration'] = int(data['runtime']) * 60
        poster = artwork_url(data.get('poster_path'), 'w500')
        fanart = artwork_url(data.get('backdrop_path'), 'w1280')
        if poster: art.update({'poster': poster, 'thumb': poster})
        if fanart: art.update({'fanart': fanart, 'landscape': fanart, 'thumb': fanart})
        cert = uk_movie_certificate(data) if is_movie else uk_tv_certificate(data)
        if cert:
            info['mpaa'] = cert
            properties['UKCertification'] = cert
        if not is_movie:
            ep = tmdb_get('/tv/%s/season/%s/episode/%s' % (tmdb_id, entry['season'], entry['number']))
            if ep:
                info['plot'] = ep.get('overview') or info.get('plot', '')
                info['title'] = ep.get('name') or info['title']
                still = artwork_url(ep.get('still_path'), 'w780')
                if still:
                    art['landscape'] = still
                    art['thumb'] = still
                if ep.get('air_date'):
                    info['premiered'] = ep['air_date']
    imdb = ids.get('imdb')
    if not imdb and data:
        imdb = data.get('imdb_id')
    if not imdb and not is_movie and tmdb_id:
        external = tmdb_get('/tv/%s/external_ids' % tmdb_id)
        imdb = external.get('imdb_id')
    omdb = omdb_get(imdb)
    if omdb.get('Response') == 'True':
        score = omdb.get('imdbRating')
        if score and score != 'N/A':
            try:
                info['rating'] = float(score)
                properties['IMDbRating'] = score
            except ValueError:
                pass
        for rating in omdb.get('Ratings') or []:
            if rating.get('Source') == 'Rotten Tomatoes':
                properties['RottenTomatoesCritics'] = rating.get('Value', '')
                break
        if not art.get('poster') and omdb.get('Poster', '').startswith('https://'):
            art['poster'] = omdb['Poster']
        if not info.get('plot') and omdb.get('Plot') not in (None, 'N/A'):
            info['plot'] = omdb['Plot']
    return info, art, properties

def continue_watching():
    entries = recent_movies() + recent_shows()
    entries.sort(key=lambda x: x.get('date') or '', reverse=True)
    for entry in entries:
        if entry['kind'] == 'movie':
            label = '%s — Resume %.0f%%' % (entry['title'], entry['progress'])
        else:
            label = '%s — %s' % (entry['title'], entry['episode'])
        item = xbmcgui.ListItem(label=label)
        item.setProperty('IsPlayable', 'true')
        info, art, props = enrich(entry)
        item.setInfo('video', info)
        if art:
            item.setArt(art)
        for key, value in props.items():
            item.setProperty(key, str(value))
        # Launches through our own route so the Umbrella URL can be diagnosed.
        route = BASE + '?' + urllib.parse.urlencode({'action': 'play', 'payload': json.dumps(entry)})
        xbmcplugin.addDirectoryItem(HANDLE, route, item, False)
    xbmcplugin.setContent(HANDLE, 'videos')


def play(payload):
    entry = json.loads(payload)
    try:
        addon = xbmcaddon.Addon('plugin.video.umbrella')
    except Exception:
        xbmcgui.Dialog().ok('Kodi Trakt Continue', 'Umbrella is not installed or enabled.')
        xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())
        return
    target = umbrella_url(entry)
    xbmc.log('[Kodi Trakt Continue] Attempting Umbrella route: %s' % target, xbmc.LOGINFO)
    # Kodi hands off to Umbrella. If this fails, report exact version and log.
    item = xbmcgui.ListItem(path=target)
    item.setProperty('IsPlayable', 'true')
    xbmcplugin.setResolvedUrl(HANDLE, True, item)


def main():
    params = urllib.parse.parse_qs(sys.argv[2][1:]) if len(sys.argv) > 2 else {}
    action = params.get('action', ['home'])[0]
    try:
        if action == 'home':
            add('CONTINUE WATCHING — Movies + TV', 'continue')
            add('Authorize Trakt', 'authorize')
            add('Open Settings', 'settings')
        elif action == 'authorize':
            authorize()
        elif action == 'settings':
            ADDON.openSettings()
        elif action == 'continue':
            continue_watching()
        elif action == 'play':
            play(params.get('payload', ['{}'])[0])
    except Exception as exc:
        xbmc.log('[Kodi Trakt Continue] %s' % exc, xbmc.LOGERROR)
        xbmcgui.Dialog().ok('Kodi Trakt Continue', str(exc))
    finally:
        if action in ('home', 'continue'):
            xbmcplugin.endOfDirectory(HANDLE, succeeded=True)


if __name__ == '__main__':
    main()
