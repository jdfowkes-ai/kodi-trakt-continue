import sys
import json
import time
import urllib.parse
import urllib.request
import urllib.error

import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin

ADDON = xbmcaddon.Addon()
HANDLE = int(sys.argv[1])
BASE = sys.argv[0]
API = 'https://api.trakt.tv'


def setting(name):
    return ADDON.getSetting(name).strip()


def url(action):
    return BASE + '?' + urllib.parse.urlencode({'action': action})


def api(path, method='GET', payload=None, authenticated=True):
    client = setting('client_id')
    if not client:
        raise RuntimeError('Enter your Trakt Client ID in add-on settings first.')
    headers = {'Content-Type': 'application/json', 'trakt-api-version': '2', 'trakt-api-key': client, 'User-Agent': 'KodiTraktContinue/0.2.0'}
    if authenticated:
        token = setting('access_token')
        if not token:
            raise RuntimeError('Authorize Trakt from the add-on main menu first.')
        headers['Authorization'] = 'Bearer ' + token
    req = urllib.request.Request(API + path, data=json.dumps(payload).encode('utf-8') if payload is not None else None, headers=headers, method=method)
    try:
        with urllib.request.urlopen(req, timeout=20) as response:
            return json.loads(response.read().decode('utf-8'))
    except urllib.error.HTTPError as exc:
        if exc.code == 401:
            raise RuntimeError('Trakt authorization expired. Reauthorize from the add-on menu.')
        if exc.code == 429:
            raise RuntimeError('Trakt rate limit reached. Please try again later.')
        raise RuntimeError('Trakt HTTP error: %s' % exc.code)


def add(label, action, info=None):
    item = xbmcgui.ListItem(label=label)
    if info:
        item.setInfo('video', info)
    xbmcplugin.addDirectoryItem(HANDLE, url(action), item, True)


def authorize():
    if not setting('client_id') or not setting('client_secret'):
        xbmcgui.Dialog().ok('Trakt setup', 'Open add-on Settings and enter your own Trakt Client ID and Client Secret.')
        ADDON.openSettings()
        return
    code = api('/oauth/device/code', method='POST', payload={'client_id': setting('client_id')}, authenticated=False)
    dialog = xbmcgui.DialogProgress()
    dialog.create('Authorize Kodi Trakt Continue', 'Visit %s and enter code %s' % (code.get('verification_url', 'https://trakt.tv/activate'), code['user_code']))
    interval = max(5, int(code.get('interval', 5)))
    deadline = time.time() + int(code.get('expires_in', 600))
    try:
        while time.time() < deadline and not dialog.iscanceled():
            xbmc.sleep(interval * 1000)
            try:
                tokens = api('/oauth/device/token', method='POST', payload={'code': code['device_code'], 'client_id': setting('client_id'), 'client_secret': setting('client_secret')}, authenticated=False)
                ADDON.setSetting('access_token', tokens['access_token'])
                ADDON.setSetting('refresh_token', tokens.get('refresh_token', ''))
                xbmcgui.Dialog().notification('Trakt', 'Authorization successful', xbmcgui.NOTIFICATION_INFO)
                return
            except RuntimeError as exc:
                # 400/404 are expected while user has not yet approved device code.
                if '400' not in str(exc) and '404' not in str(exc):
                    raise
    finally:
        dialog.close()


def recent_movies():
    # Trakt playback records are unfinished films with actual resume percentages.
    data = api('/sync/playback/movies?limit=100')
    out = []
    for entry in data:
        movie = entry.get('movie') or {}
        title = movie.get('title', 'Unknown movie')
        percent = float(entry.get('progress') or 0)
        if 0 < percent < 100:
            out.append({'kind': 'movie', 'title': title, 'date': entry.get('paused_at', ''), 'progress': percent, 'ids': movie.get('ids') or {}, 'year': movie.get('year') or ''})
    return out


def recent_shows():
    # Trakt's watched shows carry last_watched_at; next_episode is computed from progress endpoint.
    watched = api('/sync/watched/shows?extended=noseasons')
    out = []
    for entry in watched[:60]:
        show = entry.get('show') or {}
        ids = show.get('ids') or {}
        identifier = ids.get('trakt')
        if not identifier:
            continue
        progress = api('/shows/%s/progress/watched?hidden=false&specials=false' % identifier)
        nxt = progress.get('next_episode')
        if not nxt:
            continue
        season, number = nxt.get('season'), nxt.get('number')
        if season is None or number is None:
            continue
        title = show.get('title', 'Unknown series')
        out.append({'kind': 'episode', 'title': title, 'episode': 'S%02dE%02d' % (season, number), 'date': entry.get('last_watched_at') or '', 'episode_title': nxt.get('title') or '', 'ids': ids, 'year': show.get('year') or '', 'season': season, 'number': number})
    return out


def umbrella_url(entry):
    """Experimental Umbrella play route. Verify against installed Umbrella version."""
    ids = entry.get('ids') or {}
    params = {
        'action': 'play',
        'title': entry['title'],
        'year': str(entry.get('year') or ''),
        'imdb': str(ids.get('imdb') or ''),
        'tmdb': str(ids.get('tmdb') or ''),
        'select': '0',
    }
    if entry['kind'] == 'episode':
        params.update({
            'tvshowtitle': entry['title'],
            'season': str(entry['season']),
            'episode': str(entry['number']),
            'premiered': '',
        })
    return 'plugin://plugin.video.umbrella/?' + urllib.parse.urlencode(params)


def continue_watching():
    entries = recent_movies() + recent_shows()
    entries.sort(key=lambda x: x.get('date') or '', reverse=True)
    for entry in entries:
        if entry['kind'] == 'movie':
            label = '%s — Resume %.0f%%' % (entry['title'], entry['progress'])
        else:
            label = '%s — %s' % (entry['title'], entry['episode'])
        item = xbmcgui.ListItem(label=label)
        item.setProperty('IsPlayable', 'true')
        item.setInfo('video', {
            'title': entry['title'],
            'mediatype': 'movie' if entry['kind'] == 'movie' else 'episode',
        })
        # Launches through our own route so the Umbrella URL can be diagnosed.
        route = BASE + '?' + urllib.parse.urlencode({'action': 'play', 'payload': json.dumps(entry)})
        xbmcplugin.addDirectoryItem(HANDLE, route, item, False)
    xbmcplugin.setContent(HANDLE, 'videos')


def play(payload):
    entry = json.loads(payload)
    try:
        addon = xbmcaddon.Addon('plugin.video.umbrella')
    except Exception:
        xbmcgui.Dialog().ok('Kodi Trakt Continue', 'Umbrella is not installed or enabled.')
        xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())
        return
    target = umbrella_url(entry)
    xbmc.log('[Kodi Trakt Continue] Attempting Umbrella route: %s' % target, xbmc.LOGINFO)
    # Kodi hands off to Umbrella. If this fails, report exact version and log.
    item = xbmcgui.ListItem(path=target)
    item.setProperty('IsPlayable', 'true')
    xbmcplugin.setResolvedUrl(HANDLE, True, item)


def main():
    params = urllib.parse.parse_qs(sys.argv[2][1:]) if len(sys.argv) > 2 else {}
    action = params.get('action', ['home'])[0]
    try:
        if action == 'home':
            add('CONTINUE WATCHING — Movies + TV', 'continue')
            add('Authorize Trakt', 'authorize')
            add('Open Settings', 'settings')
        elif action == 'authorize':
            authorize()
        elif action == 'settings':
            ADDON.openSettings()
        elif action == 'continue':
            continue_watching()
        elif action == 'play':
            play(params.get('payload', ['{}'])[0])
    except Exception as exc:
        xbmc.log('[Kodi Trakt Continue] %s' % exc, xbmc.LOGERROR)
        xbmcgui.Dialog().ok('Kodi Trakt Continue', str(exc))
    finally:
        if action in ('home', 'continue'):
            xbmcplugin.endOfDirectory(HANDLE, succeeded=True)


if __name__ == '__main__':
    main()
